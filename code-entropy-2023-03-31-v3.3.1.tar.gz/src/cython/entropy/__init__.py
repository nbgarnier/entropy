# __all__ = ["entropy"]
# from .commons import get_last_info
# from .commons import choose_algorithm
# from .commons import multithreading
# from .others  import compute_entropy_Renyi, compute_complexities
# from .computes import *